<?php
// admin/logout.php
require_once '../includes/auth.php';
require_once '../includes/db.php';

// Oturumu sonlandır
session_start();
session_destroy();

// Çerezleri temizle
if (isset($_COOKIE[session_name()])) {
    setcookie(session_name(), '', time()-3600, '/');
}

// Tüm oturum verilerini temizle
$_SESSION = array();

// Giriş sayfasına yönlendir
echo "<script>window.location.href='login.php';</script>";
exit;