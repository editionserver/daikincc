<?php
require_once '../includes/auth.php';
require_once '../includes/db.php';

if (!isLoggedIn()) {
    echo "<script>window.location.href='login.php';</script>";
    exit;
}

// Şablon ekleme
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['name']) && isset($_POST['content'])) {
        $stmt = $conn->prepare("INSERT INTO message_templates (name, content) VALUES (?, ?)");
        $stmt->execute([$_POST['name'], $_POST['content']]);
        echo "<script>window.location.href='templates.php';</script>";
        exit;
    }
}

// Şablonları listele
$templates = $conn->query("SELECT * FROM message_templates ORDER BY created_at DESC")->fetchAll(PDO::FETCH_ASSOC);

include 'components/header.php';
?>

<h1 class="app-page-title">Mesaj Şablonları</h1>

<div class="app-card app-card-basic d-flex flex-column align-items-start shadow-sm">
    <div class="app-card-header p-3 border-bottom-0">
        <div class="row align-items-center gx-3">
            <div class="col-auto">
                <div class="app-icon-holder">
                    <svg width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-plus-square" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                        <path fill-rule="evenodd" d="M14 1H2a1 1 0 0 0-1 1v12a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V2a1 1 0 0 0-1-1zM2 0a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2H2z"/>
                        <path fill-rule="evenodd" d="M8 4a.5.5 0 0 1 .5.5v3h3a.5.5 0 0 1 0 1h-3v3a.5.5 0 0 1-1 0v-3h-3a.5.5 0 0 1 0-1h3v-3A.5.5 0 0 1 8 4z"/>
                    </svg>
                </div>
            </div>
            <div class="col-auto">
                <h4 class="app-card-title">Yeni Şablon Ekle</h4>
            </div>
        </div>
    </div>

    <div class="app-card-body px-4 w-100">
        <form method="POST">
            <div class="mb-3">
                <label class="form-label">Şablon Adı</label>
                <input type="text" class="form-control" name="name" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Şablon İçeriği</label>
                <textarea class="form-control" name="content" rows="4" required></textarea>
                <div class="form-text">Değişkenler için {degisken_adi} formatını kullanın.</div>
            </div>
            <button type="submit" class="btn app-btn-primary">Şablon Ekle</button>
        </form>
    </div>
</div>

<div class="app-card app-card-orders-table shadow-sm mb-5 mt-4">
    <div class="app-card-body">
        <div class="table-responsive">
            <table class="table app-table-hover mb-0 text-left">
                <thead>
                    <tr>
                        <th class="cell">Şablon Adı</th>
                        <th class="cell">İçerik</th>
                        <th class="cell">Oluşturma Tarihi</th>
                        <th class="cell">İşlemler</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($templates as $template): ?>
                    <tr>
                        <td class="cell"><?php echo htmlspecialchars($template['name']); ?></td>
                        <td class="cell"><?php echo htmlspecialchars($template['content']); ?></td>
                        <td class="cell"><?php echo date('d.m.Y H:i', strtotime($template['created_at'])); ?></td>
                        <td class="cell">
                            <a href="#" class="btn-sm app-btn-secondary" onclick="editTemplate(<?php echo $template['id']; ?>)">
                                Düzenle
                            </a>
                            <a href="#" class="btn-sm app-btn-danger" onclick="deleteTemplate(<?php echo $template['id']; ?>)">
                                Sil
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include 'components/footer.php'; ?>