<?php
require_once 'config/config.php';
require_once 'includes/db.php';
require_once 'includes/functions.php';

header('Content-Type: application/json');

// WhatsApp webhook doğrulama
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    if (isset($_GET['hub_challenge'])) {
        echo $_GET['hub_challenge'];
        exit;
    }
}

// Gelen webhook mesajını al
$input = file_get_contents('php://input');
$data = json_decode($input, true);

// Log tutma
file_put_contents('webhook_log.txt', date('Y-m-d H:i:s') . " - " . $input . "\n", FILE_APPEND);

if (isset($data['messages']) && !empty($data['messages'])) {
    $message = $data['messages'][0];
    $phone = $message['from'];
    $text = $message['text']['body'];
    
    // Özel şablonları kontrol et
    $template_response = checkMessageTemplates($text);
    
    if ($template_response) {
        $response = $template_response;
    } else {
        // OpenAI'dan yanıt al
        $response = getOpenAIResponse($text);
    }
    
    // Yanıtı WhatsApp'a gönder
    sendWhatsAppMessage($phone, $response);
    
    // Sohbeti kaydet
    saveChatHistory($phone, $text, $response);
    
    echo json_encode(['status' => 'success']);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Invalid webhook data']);
}