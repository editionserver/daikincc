<?php
require_once __DIR__ . '/../config/config.php';

function getOpenAIResponse($message) {
    $url = 'https://api.openai.com/v1/chat/completions';
    
    $data = [
        'model' => 'gpt-3.5-turbo',
        'messages' => [
            [
                'role' => 'system',
                'content' => 'Sen Daikin klima sistemleri konusunda uzman bir asistansın.'
            ],
            [
                'role' => 'user',
                'content' => $message
            ]
        ],
        'temperature' => 0.7
    ];

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Authorization: Bearer ' . OPENAI_API_KEY,
        'Content-Type: application/json'
    ]);

    $response = curl_exec($ch);
    curl_close($ch);

    $result = json_decode($response, true);
    return $result['choices'][0]['message']['content'];
}

function sendWhatsAppMessage($phone, $message) {
    $url = 'https://graph.facebook.com/v17.0/' . WHATSAPP_PHONE_ID . '/messages';
    
    $data = [
        'messaging_product' => 'whatsapp',
        'to' => $phone,
        'type' => 'text',
        'text' => ['body' => $message]
    ];

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Authorization: Bearer ' . WHATSAPP_API_TOKEN,
        'Content-Type: application/json'
    ]);

    $response = curl_exec($ch);
    curl_close($ch);

    return json_decode($response, true);
}

function saveChatHistory($phone, $message, $response) {
    global $conn;
    $sql = "INSERT INTO chat_history (phone, message, response) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);
    return $stmt->execute([$phone, $message, $response]);
}

function checkMessageTemplates($message) {
    global $conn;
    $sql = "SELECT content FROM message_templates WHERE ? LIKE CONCAT('%', name, '%')";
    $stmt = $conn->prepare($sql);
    $stmt->execute([$message]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    return $result ? $result['content'] : null;
}