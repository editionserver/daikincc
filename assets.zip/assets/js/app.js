"use strict";

/* Custom Scripts */
document.addEventListener('DOMContentLoaded', function() {
    // DataTables initialization
    if(document.querySelector('.datatable')) {
        $('.datatable').DataTable({
            "language": {
                "url": "//cdn.datatables.net/plug-ins/1.10.24/i18n/Turkish.json"
            },
            "pageLength": 25
        });
    }
    
    // Toast notifications
    function showToast(message, type = 'success') {
        const toast = document.createElement('div');
        toast.classList.add('toast', `toast-${type}`);
        toast.innerHTML = message;
        document.body.appendChild(toast);
        
        setTimeout(() => {
            toast.classList.add('show');
            setTimeout(() => {
                toast.classList.remove('show');
                setTimeout(() => {
                    toast.remove();
                }, 300);
            }, 3000);
        }, 100);
    }
    
    // Form validations
    const forms = document.querySelectorAll('.needs-validation');
    forms.forEach(form => {
        form.addEventListener('submit', event => {
            if (!form.checkValidity()) {
                event.preventDefault();
                event.stopPropagation();
            }
            form.classList.add('was-validated');
        });
    });
    
    // File upload preview
    const fileInputs = document.querySelectorAll('input[type="file"]');
    fileInputs.forEach(input => {
        input.addEventListener('change', event => {
            const file = event.target.files[0];
            if(file) {
                const reader = new FileReader();
                const preview = input.nextElementSibling?.querySelector('.file-preview');
                if(preview) {
                    reader.onload = e => preview.src = e.target.result;
                    reader.readAsDataURL(file);
                }
            }
        });
    });
});