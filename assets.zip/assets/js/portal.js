"use strict";

/* Sidebar Toggle */
const sidePanelToggler = document.getElementById('sidepanel-toggler');
const sidePanel = document.getElementById('app-sidepanel');
const sidePanelDrop = document.getElementById('sidepanel-drop');
const sidePanelClose = document.getElementById('sidepanel-close');

window.addEventListener('load', function(){
    responsiveSidePanel(); 
});

window.addEventListener('resize', function(){
    responsiveSidePanel(); 
});

function responsiveSidePanel() {
    let w = window.innerWidth;
	if(w >= 1200) {
	    if(sidePanel.classList.contains('panel-hidden')){
		    sidePanel.classList.remove('panel-hidden');
	    }
	    if(sidePanelDrop.classList.contains('panel-hidden')){
		    sidePanelDrop.classList.remove('panel-hidden');
	    }
	}
}

sidePanelToggler.addEventListener('click', () => {
    if (sidePanel.classList.contains('panel-hidden')) {
        sidePanel.classList.remove('panel-hidden');
        sidePanelDrop.classList.remove('panel-hidden');
    } else {
        sidePanel.classList.add('panel-hidden');
        sidePanelDrop.classList.add('panel-hidden');
    }
});

sidePanelClose.addEventListener('click', (e) => {
    e.preventDefault();
    sidePanelToggler.click();
});

sidePanelDrop.addEventListener('click', (e) => {
    sidePanelToggler.click();
});

/* Dark Mode Toggle */
const darkMode = document.getElementById('darkmode');
if(darkMode) {
    darkMode.addEventListener('click', () => {
        document.body.classList.toggle('dark-mode');
    });
}