<?php
require_once '../includes/auth.php';
require_once '../includes/db.php';

if (!isLoggedIn()) {
    echo "<script>window.location.href='login.php';</script>";
    exit;
}

// Dosya yükleme
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['file'])) {
    $file = $_FILES['file'];
    $filename = basename($file['name']);
    $upload_path = '../uploads/' . $filename;
    
    if (move_uploaded_file($file['tmp_name'], $upload_path)) {
        $stmt = $conn->prepare("INSERT INTO files (filename, filepath, filetype) VALUES (?, ?, ?)");
        $stmt->execute([$filename, $upload_path, $file['type']]);
        echo "<script>window.location.href='files.php';</script>";
        exit;
    }
}

// Dosyaları listele
$files = $conn->query("SELECT * FROM files ORDER BY uploaded_at DESC")->fetchAll(PDO::FETCH_ASSOC);

include 'components/header.php';
?>

<h1 class="app-page-title">Dosya Yönetimi</h1>

<div class="app-card app-card-basic d-flex flex-column align-items-start shadow-sm">
    <div class="app-card-header p-3 border-bottom-0">
        <div class="row align-items-center gx-3">
            <div class="col-auto">
                <div class="app-icon-holder">
                    <svg width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-upload" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                        <path fill-rule="evenodd" d="M.5 9.9a.5.5 0 0 1 .5.5v2.5a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-2.5a.5.5 0 0 1 1 0v2.5a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2v-2.5a.5.5 0 0 1 .5-.5z"/>
                        <path fill-rule="evenodd" d="M7.646 1.146a.5.5 0 0 1 .708 0l3 3a.5.5 0 0 1-.708.708L8.5 2.707V11.5a.5.5 0 0 1-1 0V2.707L5.354 4.854a.5.5 0 1 1-.708-.708l3-3z"/>
                    </svg>
                </div>
            </div>
            <div class="col-auto">
                <h4 class="app-card-title">Dosya Yükle</h4>