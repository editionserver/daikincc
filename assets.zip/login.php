<?php
require_once '../includes/auth.php';
require_once '../includes/db.php';

if (isLoggedIn()) {
    echo "<script>window.location.href='index.php';</script>";
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';
    
    if (login($username, $password)) {
        echo "<script>window.location.href='index.php';</script>";
        exit;
    } else {
        $error = 'Geçersiz kullanıcı adı veya şifre';
    }
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <title>Giriş - Daikin Bot</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <!-- FontAwesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Portal CSS -->
    <link rel="stylesheet" href="assets/css/portal.css">
    <link rel="stylesheet" href="assets/css/style.css">
</head>

<body class="app">
    <div class="row g-0 app-auth-wrapper">
        <div class="col-12 col-md-7 col-lg-6 auth-main-col text-center p-5">
            <div class="d-flex flex-column align-items-center justify-content-center h-100">
                <div class="app-auth-body mx-auto">
                    <div class="app-auth-branding mb-4">
                        <a class="app-logo" href="index.php">
                            <img class="logo-icon me-2" src="assets/images/logo.png" alt="logo">
                        </a>
                    </div>
                    <h2 class="auth-heading text-center mb-4">Daikin Bot</h2>

                    <?php if ($error): ?>
                        <div class="alert alert-danger"><?php echo $error; ?></div>
                    <?php endif; ?>

                    <div class="auth-form-container text-start mx-auto">
                        <form class="auth-form login-form" method="POST">         
                            <div class="email mb-3">
                                <label class="sr-only" for="username">Kullanıcı Adı</label>
                                <input id="username" name="username" type="text" class="form-control" 
                                       placeholder="Kullanıcı Adı" required="required">
                            </div>
                            <div class="password mb-3">
                                <label class="sr-only" for="password">Şifre</label>
                                <input id="password" name="password" type="password" class="form-control" 
                                       placeholder="Şifre" required="required">
                            </div>
                            <div class="text-center">
                                <button type="submit" class="btn app-btn-primary w-100 theme-btn mx-auto">
                                    Giriş Yap
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-12 col-md-5 col-lg-6 h-100 auth-background-col">
            <div class="auth-background-holder"></div>
            <div class="auth-background-mask"></div>
        </div>
    </div>

    <!-- Javascript -->          
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js"></script>
    <script src="assets/js/portal.js"></script>
    <script src="assets/js/app.js"></script>
</body>
</html>