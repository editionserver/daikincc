<?php
// Hata raporlamayı açalım
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Oturum ve veritabanı bağlantısı
require_once 'includes/auth.php';
require_once 'includes/db.php';

if (!isLoggedIn()) {
    header("Location: login.php");
    exit;
}

try {
    // İstatistikleri al
    $stats = [
        'total_messages' => $conn->query("SELECT COUNT(*) FROM chat_history")->fetchColumn(),
        'today_messages' => $conn->query("SELECT COUNT(*) FROM chat_history WHERE DATE(created_at) = CURDATE()")->fetchColumn(),
        'total_templates' => $conn->query("SELECT COUNT(*) FROM message_templates")->fetchColumn(),
        'total_files' => $conn->query("SELECT COUNT(*) FROM files")->fetchColumn()
    ];

    // Son mesajları al
    $stmt = $conn->query("SELECT * FROM chat_history ORDER BY created_at DESC LIMIT 10");
    $recent_messages = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (Exception $e) {
    die("Hata: " . $e->getMessage());
}

// Header'ı dahil et
include 'components/header.php';
?>

<!-- Sayfa içeriği -->
<h1 class="app-page-title">Dashboard</h1>
<!-- ... diğer içerikler ... -->

<?php 
// Footer'ı dahil et
include 'components/footer.php';
?>