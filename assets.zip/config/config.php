<?php

// config/config.php
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Veritabanı ayarları
define('DB_HOST', 'localhost');
define('DB_USER', 'soraworks_dai');
define('DB_PASS', 'Elleranelvis123');
define('DB_NAME', 'soraworks_dai');

// API Anahtarları
define('OPENAI_API_KEY', 'your-openai-api-key');
define('WHATSAPP_API_TOKEN', 'your-whatsapp-token');
define('WHATSAPP_PHONE_ID', 'your-whatsapp-phone-id');

// Uygulama ayarları
define('SITE_URL', 'https://soraworks.net');
define('UPLOAD_DIR', __DIR__ . '/../uploads/');
define('MAX_FILE_SIZE', 5 * 1024 * 1024); // 5MB
define('ALLOWED_FILE_TYPES', ['jpg', 'jpeg', 'png', 'pdf', 'doc', 'docx']);

// Hata raporlama
error_reporting(E_ALL);
ini_set('display_errors', 1);
date_default_timezone_set('Europe/Istanbul');