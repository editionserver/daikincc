</div><!--//container-fluid-->
        </div><!--//app-content-->
        
        <footer class="app-footer">
            <div class="container text-center py-3">
                <small class="copyright">© 2024 Daikin Bot. Tüm hakları saklıdır.</small>
            </div>
        </footer><!--//app-footer-->
        
    </div><!--//app-wrapper-->    					

    <!-- Javascript -->          
    <script src="assets/plugins/popper.min.js"></script>
    <script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script>  
    
    <!-- Page Specific JS -->
    <script src="assets/js/app.js"></script> 

</body>
</html>