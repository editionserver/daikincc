<div id="app-sidepanel" class="app-sidepanel">
    <div id="sidepanel-drop" class="sidepanel-drop"></div>
    <div class="sidepanel-inner d-flex flex-column">
        <a href="#" id="sidepanel-close" class="sidepanel-close d-xl-none">&times;</a>
        <div class="app-branding">
            <a class="app-logo" href="index.php">
                <span class="logo-text">Daikin Bot</span>
            </a>
        </div>

        <nav id="app-nav-main" class="app-nav app-nav-main flex-grow-1">
            <ul class="app-menu list-unstyled accordion" id="menu-accordion">
                <li class="nav-item">
                    <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) === 'index.php' ? 'active' : ''; ?>" href="index.php">
                        <span class="nav-icon"><i class="fas fa-home"></i></span>
                        <span class="nav-link-text">Dashboard</span>
                    </a>
                </li>
                
                <li class="nav-item">
                    <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) === 'templates.php' ? 'active' : ''; ?>" href="templates.php">
                        <span class="nav-icon"><i class="fas fa-file-alt"></i></span>
                        <span class="nav-link-text">Şablonlar</span>
                    </a>
                </li>

                <li class="nav-item">
                    <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) === 'chat-history.php' ? 'active' : ''; ?>" href="chat-history.php">
                        <span class="nav-icon"><i class="fas fa-history"></i></span>
                        <span class="nav-link-text">Sohbet Geçmişi</span>
                    </a>
                </li>

                <li class="nav-item">
                    <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) === 'files.php' ? 'active' : ''; ?>" href="files.php">
                        <span class="nav-icon"><i class="fas fa-folder"></i></span>
                        <span class="nav-link-text">Dosyalar</span>
                    </a>
                </li>

                <li class="nav-item">
                    <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) === 'settings.php' ? 'active' : ''; ?>" href="settings.php">
                        <span class="nav-icon"><i class="fas fa-cog"></i></span>
                        <span class="nav-link-text">Ayarlar</span>
                    </a>
                </li>
            </ul>
        </nav>
    </div>
</div>