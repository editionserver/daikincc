<?php
require_once '../includes/auth.php';
require_once '../includes/db.php';

if (!isLoggedIn()) {
    echo "<script>window.location.href='login.php';</script>";
    exit;
}

// Filtreleme ve arama
$search = $_GET['search'] ?? '';
$date_from = $_GET['date_from'] ?? '';
$date_to = $_GET['date_to'] ?? '';

$sql = "SELECT * FROM chat_history WHERE 1=1";
$params = [];

if ($search) {
    $sql .= " AND (message LIKE ? OR response LIKE ? OR phone LIKE ?)";
    $params = array_merge($params, ["%$search%", "%$search%", "%$search%"]);
}

if ($date_from) {
    $sql .= " AND DATE(created_at) >= ?";
    $params[] = $date_from;
}

if ($date_to) {
    $sql .= " AND DATE(created_at) <= ?";
    $params[] = $date_to;
}

$sql .= " ORDER BY created_at DESC LIMIT 100";

$stmt = $conn->prepare($sql);
$stmt->execute($params);
$messages = $stmt->fetchAll(PDO::FETCH_ASSOC);

include 'components/header.php';
?>

<h1 class="app-page-title">Sohbet Geçmişi</h1>

<div class="app-card app-card-basic d-flex flex-column align-items-start shadow-sm">
    <div class="app-card-header p-3 border-bottom-0">
        <div class="row align-items-center gx-3">
            <div class="col-auto">
                <div class="app-icon-holder">
                    <svg width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-search" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                        <path fill-rule="evenodd" d="M10.442 10.442a1 1 0 0 1 1.415 0l3.85 3.85a1 1 0 0 1-1.414 1.415l-3.85-3.85a1 1 0 0 1 0-1.415z"/>
                        <path fill-rule="evenodd" d="M6.5 12a5.5 5.5 0 1 0 0-11 5.5 5.5 0 0 0 0 11zM13 6.5a6.5 6.5 0 1 1-13 0 6.5 6.5 0 0 1 13 0z"/>
                    </svg>
                </div>
            </div>
            <div class="col-auto">
                <h4 class="app-card-title">Mesaj Ara</h4>
            </div>
        </div>
    </div>

    <div class="app-card-body px-4 w-100">
        <form method="GET" class="row g-3">
            <div class="col-md-4">
                <label class="form-label">Arama</label>
                <input type="text" class="form-control" name="search" value="<?php echo htmlspecialchars($search); ?>" placeholder="Mesaj veya telefon...">
            </div>
            <div class="col-md-3">
                <label class="form-label">Başlangıç Tarihi</label>
                <input type="date" class="form-control" name="date_from" value="<?php echo $date_from; ?>">
            </div>
            <div class="col-md-3">
                <label class="form-label">Bitiş Tarihi</label>
                <input type="date" class="form-control" name="date_to" value="<?php echo $date_to; ?>">
            </div>
            <div class="col-md-2 d-flex align-items-end">
                <button type="submit" class="btn app-btn-primary w-100">Filtrele</button>
            </div>
        </form>
    </div>
</div>

<div class="app-card app-card-orders-table shadow-sm mb-5 mt-4">
    <div class="app-card-body">
        <div class="table-responsive">
            <table class="table app-table-hover mb-0 text-left">
                <thead>
                    <tr>
                        <th class="cell">Telefon</th>
                        <th class="cell">Mesaj</th>
                        <th class="cell">Yanıt</th>
                        <th class="cell">Tarih</th>
                        <th class="cell">İşlemler</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($messages as $message): ?>
                    <tr>
                        <td class="cell"><?php echo htmlspecialchars($message['phone']); ?></td>
                        <td class="cell"><?php echo htmlspecialchars($message['message']); ?></td>
                        <td class="cell"><?php echo htmlspecialchars($message['response']); ?></td>
                        <td class="cell"><?php echo date('d.m.Y H:i', strtotime($message['created_at'])); ?></td>
                        <td class="cell">
                            <a href="#" class="btn-sm app-btn-secondary" onclick="showDetails(<?php echo $message['id']; ?>)">
                                Detay
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Modal -->
<div class="modal fade" id="detailsModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Mesaj Detayları</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <!-- Detaylar buraya gelecek -->
            </div>
        </div>
    </div>
</div>

<script>
function showDetails(id) {
    // AJAX ile mesaj detaylarını al
    fetch(`get_message_details.php?id=${id}`)
        .then(response => response.json())
        .then(data => {
            document.querySelector('.modal-body').innerHTML = `
                <p><strong>Telefon:</strong> ${data.phone}</p>
                <p><strong>Tarih:</strong> ${data.created_at}</p>
                <p><strong>Mesaj:</strong></p>
                <pre>${data.message}</pre>
                <p><strong>Yanıt:</strong></p>
                <pre>${data.response}</pre>
            `;
            new bootstrap.Modal(document.getElementById('detailsModal')).show();
        });
}
</script>

<?php include 'components/footer.php'; ?>