<?php
require_once '../includes/auth.php';
require_once '../includes/db.php';

if (!isLoggedIn()) {
    echo "<script>window.location.href='login.php';</script>";
    exit;
}

$success_message = '';
$error_message = '';

// Ayarları kaydet
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        // API Ayarları
        if (isset($_POST['api_settings'])) {
            $openai_key = $_POST['openai_api_key'];
            $whatsapp_token = $_POST['whatsapp_token'];
            
            // config.php dosyasını güncelle
            $config_content = file_get_contents('../config/config.php');
            $config_content = preg_replace(
                "/define\('OPENAI_API_KEY',\s*'.*?'\);/",
                "define('OPENAI_API_KEY', '$openai_key');",
                $config_content
            );
            $config_content = preg_replace(
                "/define\('WHATSAPP_API_TOKEN',\s*'.*?'\);/",
                "define('WHATSAPP_API_TOKEN', '$whatsapp_token');",
                $config_content
            );
            
            file_put_contents('../config/config.php', $config_content);
        }
        
        // Şifre değiştirme
        if (isset($_POST['change_password'])) {
            $current_password = $_POST['current_password'];
            $new_password = $_POST['new_password'];
            $confirm_password = $_POST['confirm_password'];
            
            if ($new_password !== $confirm_password) {
                throw new Exception("Yeni şifreler eşleşmiyor!");
            }
            
            $user_id = $_SESSION['user_id'];
            $stmt = $conn->prepare("SELECT password FROM users WHERE id = ?");
            $stmt->execute([$user_id]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($user['password'] !== md5($current_password)) {
                throw new Exception("Mevcut şifre yanlış!");
            }
            
            $new_password_hash = md5($new_password);
            $stmt = $conn->prepare("UPDATE users SET password = ? WHERE id = ?");
            $stmt->execute([$new_password_hash, $user_id]);
        }
        
        $success_message = "Ayarlar başarıyla güncellendi!";
    } catch (Exception $e) {
        $error_message = $e->getMessage();
    }
}

// Mevcut ayarları al
$openai_key = defined('OPENAI_API_KEY') ? OPENAI_API_KEY : '';
$whatsapp_token = defined('WHATSAPP_API_TOKEN') ? WHATSAPP_API_TOKEN : '';

include 'components/header.php';
?>

<div class="content">
    <h1 class="page-title">Ayarlar</h1>
    
    <?php if ($success_message): ?>
        <div class="alert alert-success"><?php echo $success_message; ?></div>
    <?php endif; ?>
    
    <?php if ($error_message): ?>
        <div class="alert alert-danger"><?php echo $error_message; ?></div>
    <?php endif; ?>
    
    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
        <!-- API Ayarları -->
        <div class="card">
            <h2>API Ayarları</h2>
            <form method="POST" class="space-y-4">
                <input type="hidden" name="api_settings" value="1">
                
                <div class="form-group">
                    <label>OpenAI API Anahtarı:</label>
                    <input type="password" name="openai_api_key" value="<?php echo htmlspecialchars($openai_key); ?>" required>
                </div>
                
                <div class="form-group">
                    <label>WhatsApp API Token:</label>
                    <input type="password" name="whatsapp_token" value="<?php echo htmlspecialchars($whatsapp_token); ?>" required>
                </div>
                
                <button type="submit" class="btn btn-primary">API Ayarlarını Kaydet</button>
            </form>
        </div>
        
        <!-- Şifre Değiştirme -->
        <div class="card">
            <h2>Şifre Değiştir</h2>
            <form method="POST" class="space-y-4">
                <input type="hidden" name="change_password" value="1">
                
                <div class="form-group">
                    <label>Mevcut Şifre:</label>
                    <input type="password" name="current_password" required>
                </div>
                
                <div class="form-group">
                    <label>Yeni Şifre:</label>
                    <input type="password" name="new_password" required>
                </div>
                
                <div class="form-group">
                    <label>Yeni Şifre (Tekrar):</label>
                    <input type="password" name="confirm_password" required>
                </div>
                
                <button type="submit" class="btn btn-primary">Şifreyi Değiştir</button>
            </form>
        </div>
        
        <!-- Sistem Bilgileri -->
        <div class="card">
            <h2>Sistem Bilgileri</h2>
            <div class="space-y-2">
                <p><strong>PHP Versiyonu:</strong> <?php echo phpversion(); ?></p>
                <p><strong>MySQL Versiyonu:</strong> <?php echo $conn->getAttribute(PDO::ATTR_SERVER_VERSION); ?></p>
                <p><strong>Maksimum Dosya Boyutu:</strong> <?php echo ini_get('upload_max_filesize'); ?></p>
                <p><strong>Sunucu:</strong> <?php echo $_SERVER['SERVER_SOFTWARE']; ?></p>
            </div>
        </div>
    </div>
</div>

<?php include 'components/footer.php'; ?>